package com.example.tugaspraktpm5;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class Liga1Data {
    @NotNull
    public static ArrayList<Liga1Model> generateLiga1() {
        ArrayList<Liga1Model> Liga1 = new ArrayList<>();

        Liga1.add(new Liga1Model(
                "https://upload.wikimedia.org/wikipedia/en/thumb/1/10/Persib_logo.svg/1200px-Persib_logo.svg.png",
                "Persib Bandung",
                "Jawa Barat",
                " "
        ));
        Liga1.add(new Liga1Model(
                "https://upload.wikimedia.org/wikipedia/en/9/94/Persija_Jakarta_logo.png",
                "Persija Jakarta",
                "DKI Jakarta",
                ""
        ));
        Liga1.add(new Liga1Model(
                "https://upload.wikimedia.org/wikipedia/en/thumb/a/a1/Persebaya_logo.svg/1200px-Persebaya_logo.svg.png",
                "Persebaya Surabaya",
                "Jawa Timur",
                " "
        ));
        Liga1.add(new Liga1Model(
                "https://upload.wikimedia.org/wikipedia/en/thumb/c/c9/PSS_Sleman_logo.svg/1200px-PSS_Sleman_logo.svg.png",
                "PSS Sleman",
                "D.I. Yogyakarta",
                " "
        ));
        Liga1.add(new Liga1Model(
                "https://upload.wikimedia.org/wikipedia/en/thumb/4/43/PSM_Makassar_logo.svg/1200px-PSM_Makassar_logo.svg.png",
                "PSM Makassar",
                "Sulawesi Selatan",
                " "
        ));
        Liga1.add(new Liga1Model(
                "https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Logo_PSIS_Semarang_hd.png/1200px-Logo_PSIS_Semarang_hd.png",
                "PSIS Semarang",
                "Jawa Tengah",
                " "
        ));
        Liga1.add(new Liga1Model(
                "https://upload.wikimedia.org/wikipedia/en/thumb/6/60/Persipura_logo.svg/1200px-Persipura_logo.svg.png",
                "PERSIPURA Jayapura",
                "Papua",
                " "
        ));
        Liga1.add(new Liga1Model(
                "https://upload.wikimedia.org/wikipedia/en/thumb/5/5e/Bali_United_logo.svg/1200px-Bali_United_logo.svg.png",
                "Bali United",
                "Bali",
                " "
        ));
        Liga1.add(new Liga1Model(
                "https://upload.wikimedia.org/wikipedia/en/thumb/4/4c/Persik_Kediri_logo.svg/1200px-Persik_Kediri_logo.svg.png",
                "Persik Kediri",
                "Jawa Timur",
                " "
        ));
        Liga1.add(new Liga1Model(
                "https://admincms.maduraunitedfc.com/assets/gambar/madura%20united.png",
                "Madura Untied",
                "Jawa Timur",
                " "
        ));
        Liga1.add(new Liga1Model(
                "https://upload.wikimedia.org/wikipedia/en/thumb/f/f4/Persela_logo.svg/1200px-Persela_logo.svg.png",
                "Persela Lamongan",
                "Jawa Timur",
                " "
        ));
        Liga1.add(new Liga1Model(
                "https://upload.wikimedia.org/wikipedia/en/thumb/d/d6/Barito_Putera_logo.svg/1200px-Barito_Putera_logo.svg.png",
                "Barito Putera",
                "Kalimantan Selatan",
                ""
                ));
        Liga1.add(new Liga1Model(
                "https://upload.wikimedia.org/wikipedia/en/thumb/6/6c/Borneo_FC_logo_%282021%29.svg/1200px-Borneo_FC_logo_%282021%29.svg.png",
                "Borneo FC",
                "Kalimantan Timur",
                " "
        ));
        Liga1.add(new Liga1Model(
                "https://upload.wikimedia.org/wikipedia/id/thumb/9/95/Persita_logo_%282020%29.svg/1200px-Persita_logo_%282020%29.svg.png",
                "Persita Tangerang",
                "Banten",
                ""
        ));
        Liga1.add(new Liga1Model(
                "https://upload.wikimedia.org/wikipedia/id/thumb/4/40/Logo_Arema_FC_2017_logo.svg/1200px-Logo_Arema_FC_2017_logo.svg.png",
                "Arem Arem",
                "Antah berantah",
                "TIM ELEK RAONO KETEREANGANE."
        ));
        return Liga1;
    }
}

