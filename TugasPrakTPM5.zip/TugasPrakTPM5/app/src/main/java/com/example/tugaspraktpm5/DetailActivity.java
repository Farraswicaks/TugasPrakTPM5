package com.example.tugaspraktpm5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        if(getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        ImageView img       = findViewById(R.id.Liga1_image_detail);
        TextView nameTxt    = findViewById(R.id.Liga1_name_detail);
        TextView provinsiTxt    = findViewById(R.id.Liga1_provinsi_detail);
        TextView keteranganTxt = findViewById(R.id.Liga1_keterangan_detail);

        Bundle extras = getIntent().getExtras();

        String image      = extras.getString("IMAGE_KEY");
        String name       = extras.getString("NAME_KEY");
        String provinsi   = extras.getString("PROVINSI_KEY");
        String keterangan = extras.getString("KETERANGAN_KEY");

        setTitle("Detail "+ name);

//        img.setImageURI(Uri.parse(image));
        Glide.with(this)
                .load(image)
                .into(img);

        nameTxt.setText(name);
        provinsiTxt.setText(provinsi);
        keteranganTxt.setText(keterangan);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
