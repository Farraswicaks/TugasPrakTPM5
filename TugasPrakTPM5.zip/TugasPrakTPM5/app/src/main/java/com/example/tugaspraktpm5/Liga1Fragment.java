package com.example.tugaspraktpm5;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class Liga1Fragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        return inflater.inflate(R.layout.fragment_liga1, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().setTitle("Liga1 INDONESIA");

        Liga1Adapter Liga1Adapter = new Liga1Adapter(Liga1Data.generateLiga1(),getContext());
        RecyclerView rvLiga1 = getView().findViewById(R.id.rv_Liga1_list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());

        rvLiga1.setLayoutManager(layoutManager);
        rvLiga1.setHasFixedSize(true);
        rvLiga1.setAdapter(Liga1Adapter);
    }
}
