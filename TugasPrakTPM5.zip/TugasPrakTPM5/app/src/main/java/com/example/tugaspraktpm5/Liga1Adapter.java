package com.example.tugaspraktpm5;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class Liga1Adapter extends RecyclerView.Adapter<Liga1Adapter.ViewHolder>{
private ArrayList<Liga1Model> listLiga1;
private Context context;

public Liga1Adapter(ArrayList<Liga1Model> dataList, Context context) {
        this.listLiga1 = dataList;
        this.context = context;
        }

@NonNull @Override
public ViewHolder onCreateViewHolder(@NotNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item_list_liga1, parent, false);
        return new ViewHolder(view);
        }

@Override
public void onBindViewHolder(@NonNull Liga1Adapter.ViewHolder holder, int position) {
        String image    = listLiga1.get(position).getImage();
        String name     = listLiga1.get(position).getName();
        String provinsi     = listLiga1.get(position).getProvinsi();
        String keterangan  = listLiga1.get(position).getKeterangan();

        Glide.with(holder.itemView.getContext())
        .load(listLiga1.get(position).getImage())
        .into(holder.image);

        holder.name.setText(name);
        holder.provinsi.setText(provinsi);
        holder.keterangan.setText(keterangan);

        holder.btnPreview.setOnClickListener(v -> {
        Intent i = new Intent(context, DetailActivity.class);
        i.putExtra("IMAGE_KEY", image);
        i.putExtra("NAME_KEY", name);
        i.putExtra("PROVINSI_KEY", provinsi);
        i.putExtra("KETERANGAN_KEY", keterangan);
        context.startActivity(i);
        });
        }

@Override
public int getItemCount() {
        return (listLiga1 != null) ? listLiga1.size() : 0;
        }

public static class ViewHolder extends RecyclerView.ViewHolder {
    private final ImageView image;
    private final TextView name, provinsi, keterangan;
    private final Button btnPreview;

    public ViewHolder(View itemView) {
        super(itemView);
        image      = itemView.findViewById(R.id.Liga1_image);
        name       = itemView.findViewById(R.id.Liga1_name);
        provinsi       = itemView.findViewById(R.id.Liga1_provinsi);
        keterangan    = itemView.findViewById(R.id.Liga1_keterangan);
        btnPreview = itemView.findViewById(R.id.btnPreview);
    }
}
}
