package com.example.tugaspraktpm5;

public class Liga1Model {
    private String image,name,provinsi,keterangan;

    public Liga1Model(String image, String name, String provinsi, String keterangan) {
        this.image   = image;
        this.name    = name;
        this.provinsi    = provinsi;
        this.keterangan = keterangan;
    }

    public String getImage() {
        return image;
    }
    public String getName() {
        return name;
    }
    public String getProvinsi() {
        return provinsi;
    }
    public String getKeterangan() {
        return keterangan;
    }
}
